from django import forms
'''
class Employee1(forms.Form):
    eno=forms.CharField()
    ename=forms.CharField(max_length=1000)
    esal=forms.CharField(max_length=1000)
'''

