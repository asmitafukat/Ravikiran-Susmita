from django.db import models

# Create your models here.

class Employee1(models.Model):
    eno=models.CharField(max_length=20)
    ename=models.CharField(max_length=1000)
    esal=models.CharField(max_length=1000)

    def __str__(self):
        return self.ename
