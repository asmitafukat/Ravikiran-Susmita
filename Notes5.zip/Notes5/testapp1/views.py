from django.shortcuts import render
from testapp1.models import Employee1
from django.http import HttpResponseRedirect
#from testapp1.forms import Employee1

# Create your views here.


def addemp(request):
    if request.method == "POST":
        en = request.POST.get("eno")
        enm = request.POST.get("ename")
        esl = request.POST.get("esal")
        #print("Eno. - ",en)
        #print("Name - ",enm)
        #print("Salary _ ",esl)
        emp = Employee1()
        emp.eno = en
        emp.ename = enm
        emp.esal = esl
        emp.save()
        print("This is post request")
    else:
        print("This is get")
    return render(request,'testapp1/Project.html')


def show(request):
    employee = Employee1.objects.all()
    return render(request,'testapp1/Form.html',{'employee': employee})

def home(request):
    return render(request,'testapp1/home.html')

def delete(request,id):
    rec = Employee1.objects.get(id=id)
    rec.delete()
    return HttpResponseRedirect('/Show')

def update(request,id):
    if request.method == "POST":
        en = request.POST.get("eno")
        enm = request.POST.get("ename")
        esl = request.POST.get("esal")
        emp = Employee1(id=id,eno=en, ename=enm, esal=esl)
        emp.save()
        return HttpResponseRedirect('/Show/')

    else:
        emp=Employee1.objects.get(id=id)
        return render(request,'testapp1/Update.html',{"emp":emp})
